from PyQt5.QtWidgets import QAction
from .river_flow_analyzer import RiverFlowAnalyzer
from PyQt5.QtGui import QIcon
import os


class RiverFlowAnalyzerPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.analyzer = None
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        if os.path.exists(icon_path):
            self.action = QAction(QIcon(icon_path), "Nehir Akış Analizi", self.iface.mainWindow())
        else:
            self.action = QAction("Nehir Akış Analizi", self.iface.mainWindow())

        self.action.triggered.connect(self.run)

        # Menü ve araç çubuğuna ekle
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&River Tools", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("&River Tools", self.action)

        # Açık diyalogları kapat
        if self.dialog:
            self.dialog.close()
            self.dialog = None

        self.analyzer = None

    def run(self):
        if not self.analyzer:
            self.analyzer = RiverFlowAnalyzer(self.iface)

        # Diyaloğu oluştur ve göster
        self.dialog = self.analyzer.run()
        self.dialog.show()


def classFactory(iface):
    from .river_flow_analyzer import RiverFlowAnalyzer
    return RiverFlowAnalyzerPlugin(iface)